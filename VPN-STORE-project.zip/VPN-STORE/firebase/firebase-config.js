// 1) Create a Firebase project, enable Email/Password Authentication, Firestore and Storage.
// 2) Replace every value below with your Firebase Web App configuration.
// Firebase web config is public by design; security comes from Auth, Rules and server-side checks.
export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_WEB_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.firebasestorage.app",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
export const FUNCTIONS_REGION = "asia-south1";
