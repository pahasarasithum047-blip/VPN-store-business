import { auth, db, configured } from "./firebase.js";
import { createUserWithEmailAndPassword, signInWithEmailAndPassword, updateProfile } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import { doc, setDoc, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import { showMessage } from "./main.js";
const rf=document.querySelector("#register-form"), lf=document.querySelector("#login-form"), msg=document.querySelector("#auth-message");
if(rf)rf.addEventListener("submit",async e=>{e.preventDefault();if(!configured)return showMessage(msg,"Add your Firebase configuration first.",true);const f=new FormData(rf);try{const cred=await createUserWithEmailAndPassword(auth,f.get("email"),f.get("password"));await updateProfile(cred.user,{displayName:f.get("name")});await setDoc(doc(db,"users",cred.user.uid),{name:f.get("name"),phone:f.get("phone"),email:f.get("email"),createdAt:serverTimestamp()});location.href="dashboard.html";}catch(err){showMessage(msg,err.message,true);}});
if(lf)lf.addEventListener("submit",async e=>{e.preventDefault();if(!configured)return showMessage(msg,"Add your Firebase configuration first.",true);const f=new FormData(lf);try{await signInWithEmailAndPassword(auth,f.get("email"),f.get("password"));location.href="dashboard.html";}catch(err){showMessage(msg,err.message,true);}});
