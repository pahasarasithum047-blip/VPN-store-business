import {auth,functions,db,configured} from "./firebase.js";
import {onAuthStateChanged} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-auth.js";
import {httpsCallable} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-functions.js";
import {doc,getDoc} from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
import {showMessage} from "./main.js";
const btn=document.querySelector("#trial-btn"),msg=document.querySelector("#trial-message"),status=document.querySelector("#trial-status");let user=null;
onAuthStateChanged(auth,async u=>{user=u;if(!u){btn.textContent="LOGIN TO GET FREE VPN";return;}if(!configured)return;const s=await getDoc(doc(db,"trials",u.uid));if(s.exists()){const t=s.data();status.textContent=`Status: ${t.status}. Expires: ${t.expiresAt?.toDate?.().toLocaleString()||"—"}`;btn.textContent=t.status==="ACTIVE"?"DOWNLOAD TRIAL FILE":"TRIAL ALREADY USED";}});
btn?.addEventListener("click",async()=>{if(!user){location.href="login.html";return;}try{if(btn.textContent==="DOWNLOAD TRIAL FILE"){const f=httpsCallable(functions,"createTrialDownload");const r=await f();location.href=r.data.url;return;}const f=httpsCallable(functions,"activateFreeTrial");const r=await f();showMessage(msg,`Trial activated. Expires ${new Date(r.data.expiresAt).toLocaleString()}`);btn.textContent="DOWNLOAD TRIAL FILE";}catch(e){showMessage(msg,e.message,true);}});
