import { db, configured } from "./firebase.js";
import { collection, getDocs, query, where, doc, getDoc } from "https://www.gstatic.com/firebasejs/10.14.1/firebase-firestore.js";
const nav = document.querySelector("#site-nav");
if (nav) nav.innerHTML = `<header class="site-nav"><div class="container nav-inner"><a class="brand" href="index.html"><img src="assets/logo.png" alt="VPN STORE logo" onerror="this.style.display='none'"><span>VPN STORE</span></a><button class="menu-toggle" aria-label="Open menu">☰</button><nav class="nav-links"><a href="index.html">Home</a><a href="packages.html">VPN Packages</a><a href="free-vpn.html">Free VPN</a><a href="login.html">Login</a><a href="#contact-links">Contact Us</a></nav></div></header>`;
document.querySelector(".menu-toggle")?.addEventListener("click",()=>document.querySelector(".nav-links")?.classList.toggle("open"));
const foot=document.querySelector("#site-footer");
if(foot) foot.innerHTML=`<footer class="site-footer"><div class="container footer-inner"><span>© ${new Date().getFullYear()} VPN STORE. All rights reserved.</span><span>FAST • SECURE • PRIVATE</span></div></footer>`;
export async function loadSettings(){
 if(!configured)return {};
 try{const s=await getDoc(doc(db,"settings","public"));return s.exists()?s.data():{};}catch{return {};}
}
export function showMessage(el,msg,isError=false){if(el){el.textContent=msg;el.style.color=isError?"#ff8585":"#39ff14";}}
export async function renderContact(){
 const target=document.querySelector("#contact-links");if(!target)return;
 const s=await loadSettings();
 target.innerHTML=`${s.supportPhone?`<a class="btn primary" href="https://wa.me/${String(s.supportPhone).replace(/\\D/g,"")}">WhatsApp Support</a>`:""}${s.channelUrl?`<a class="btn outline" target="_blank" rel="noopener" href="${s.channelUrl}">WhatsApp Channel</a>`:""}${s.communityUrl?`<a class="btn outline" target="_blank" rel="noopener" href="${s.communityUrl}">WhatsApp Community</a>`:""}`;
}
export async function renderFeatured(){
 const target=document.querySelector("#featured-packages");if(!target)return;
 if(!configured){target.innerHTML='<p class="muted">Connect Firebase and publish packages to display live plans.</p>';return;}
 try{const snap=await getDocs(query(collection(db,"packages"),where("enabled","==",true)));target.innerHTML=snap.docs.slice(0,3).map(d=>{const p=d.data();return `<article class="package-card"><span class="eyebrow">${p.category||"VPN PACKAGE"}</span><h3>${escapeHtml(p.name||"VPN Plan")}</h3><div class="price">Rs. ${Number(p.price).toLocaleString("en-LK")}</div><p>${escapeHtml(p.dataAllowance||"") } · ${escapeHtml(p.validity||"")}</p><a class="btn outline" href="packages.html">VIEW PACKAGE</a></article>`}).join("")||'<p class="muted">No packages are available yet.</p>';}catch{target.textContent="Unable to load packages.";}}
export function escapeHtml(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
renderContact();renderFeatured();
