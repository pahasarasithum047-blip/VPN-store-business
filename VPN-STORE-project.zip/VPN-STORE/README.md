# VPN STORE — Firebase web application starter

This is a deployable project scaffold with customer registration/login, live package listing, checkout receipt upload, customer dashboard, admin payment review, private VPN-file delivery and a 24-hour trial authorization.

## Before launch

**The included files are a working integration scaffold, not a live VPN service.** You must connect Firebase, upload your actual logo and package files, configure administrator claims, and integrate VPN-server usage enforcement. The 1GB trial limit is NOT enforced by this website; configure it in your VPN server/provider API.

## 1. Add your logo

Put your exact original logo at `assets/logo.png`. It is referenced without recoloring, cropping or stretching (`object-fit:contain`). The logo was not present as an accessible attachment when this ZIP was generated, so this folder contains an `assets/LOGO_GOES_HERE.txt` reminder.

## 2. Firebase setup

1. Create a Firebase project.
2. Add a Web App and copy its config into `js/firebase-config.js`.
3. Enable Email/Password in Authentication.
4. Create Firestore database and Storage bucket.
5. Deploy `firestore.rules` and `storage.rules`.
6. From `functions/`, run `npm install`, then deploy Functions using Firebase CLI (`firebase deploy --only functions`).
7. Set `functions` region to match `asia-south1` or change both frontend and backend consistently.
8. Host the static site using Firebase Hosting or another HTTPS static host. Do not open the pages directly as `file://`; ES modules and Firebase require a web server.

## 3. Create an administrator

Do not put admin passwords or service-account keys in browser code. Use a trusted local Admin SDK environment and set a custom claim on the intended account:

```js
const admin = require('firebase-admin');
admin.initializeApp();
await admin.auth().setCustomUserClaims('FIREBASE_AUTH_UID', { admin: true });
```

Run this only in a trusted server/local environment with Firebase Admin credentials. Sign out and sign back in after setting the claim.

## 4. Create packages

In Firestore, create documents in `packages`. Example fields:

```json
{
  "name": "Mobile 100GB",
  "category": "mobile",
  "dataAllowance": "100GB",
  "price": 200,
  "validity": "30 days",
  "description": "Mobile VPN package",
  "enabled": true
}
```

For router plans use `"category": "router"`. The package document ID is used in checkout URLs. The admin dashboard in this starter handles orders, private file upload and public settings; package CRUD can be added once your Firebase project is configured.

## 5. Secure file workflow

VPN files are stored under `vpn-private/` and Storage rules deny direct access. Cloud Functions generate short-lived signed URLs only after checking the customer's approved order or active trial. Upload metadata is initiated by a callable function, then the browser uploads the bytes to the returned private path.

The backend must be deployed before file upload/download actions work. For production, consider moving file upload fully into a server endpoint that validates content and metadata, and add malware scanning.

## 6. Free trial data cap

The website creates one trial record per Firebase account and sets a 24-hour expiry. It does **not** limit VPN traffic to 1GB. You must integrate a VPN control plane/provider API to provision a unique account, track bytes used, suspend at 1GB, and revoke access at expiry. Add verified phone identity / abuse prevention if one-trial-per-person is required; Firebase account uniqueness alone does not stop someone creating multiple accounts.

## 7. Payment review

Receipt upload creates a `PENDING` order. Only an administrator with the `admin` custom claim can approve or reject it through a Cloud Function. The app never treats receipt upload as proof of payment. An admin must verify the bank transaction independently.

## 8. Important production hardening

- Enable Firebase App Check and configure it for Firestore, Storage and callable Functions.
- Add email verification and require verified email before activating a trial or placing orders.
- Add rate limiting, bot protection and phone verification to prevent duplicate trial abuse.
- Configure Firebase budget alerts and restrict API keys by allowed domains.
- Add transactional outbox/email/WhatsApp notification integration; this starter does not send notifications.
- Add package CRUD and customer-management screens; package documents can currently be maintained in Firestore Console.
- Test all security rules with Firebase Emulator Suite before accepting payments.
- Have your VPN provider confirm that reselling and distributing configurations is permitted.
